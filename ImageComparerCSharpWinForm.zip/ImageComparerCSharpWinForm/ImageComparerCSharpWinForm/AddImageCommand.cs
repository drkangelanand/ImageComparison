﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace ImageComparerCSharpWinForm
{
    public class AddImageCommand : CommandBase
    {
        private readonly ImageComparerWebFormViewModel _icwvm;
        private readonly int _imageNumber;
        public AddImageCommand(ImageComparerWebFormViewModel cvm, int imageNumber)
        {
            _icwvm = cvm;
            _imageNumber = imageNumber;
        }

        public override void Execute(object parameter)
        {
            _icwvm.AddAnImage((BitmapImage)parameter, _imageNumber);
        }
    }
}


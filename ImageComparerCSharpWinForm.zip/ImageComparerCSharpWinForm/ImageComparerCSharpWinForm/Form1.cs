﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Windows;

namespace ImageComparerCSharpWinForm
{
    public partial class Form1 : Form
    {
        ImageComparerWebFormViewModel DataContext;
        public Form1()
        {
            InitializeComponent();
            DataContext = new ImageComparerWebFormViewModel();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BitmapImage img = GetImage(pictureBox1);
            // Process open file dialog box results
            if (img != null)
            {
                // Open document
                (DataContext).AddImage1.Execute(img);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            BitmapImage img = GetImage(pictureBox2);
            // Process open file dialog box results
            if (img != null)
            {
                // Open document
                (DataContext).AddImage2.Execute(img);
            }
        }

        BitmapImage GetImage(PictureBox p)
        {

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.FileName = "Open Image"; // Default file name
            //dlg.DefaultExt = ".jpg"; // Default file extension
            dlg.Filter = "Images |*.jpg;*.jpeg;*.png;*.bmp;*.gif"; // Filter files by extension

            // Show open file dialog box
            Nullable<bool> result = dlg.ShowDialog() == DialogResult.OK;
            if (result == true)
            {
                p.Image = new Bitmap(dlg.FileName);
                return new BitmapImage(new Uri(dlg.FileName));
            }
            return null;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DauntLess.Classes
{
    public class OperationResult
    {
        public bool Checked { get; set; }
        public double PercentDifference { get; set; }
        public string Image1 { get; set; }
        public string Image2 { get; set; }
    }
}

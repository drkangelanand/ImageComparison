﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DauntLess.ImageComparison.FindSimilarity
{
    static class StaticSession
    {
        public static SimilarImage sm = new SimilarImage();
        public static List<SimilarImage> similarImagesList = new List<SimilarImage>();
    }
}
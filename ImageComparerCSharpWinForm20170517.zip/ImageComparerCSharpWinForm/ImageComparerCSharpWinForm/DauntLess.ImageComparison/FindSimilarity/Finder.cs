﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;


namespace DauntLess.ImageComparison.FindSimilarity
{
    public class Finder
    {

        public static bool AreImagesSimilar(string imgPath1, string imgPath2, double threshhold = 10d)
        {
            ImageComparerViewModel DataContext = new ImageComparerViewModel();

            BitmapImage img1 = new BitmapImage(new Uri(imgPath1));
            MyImage mi1 = new MyImage();
            mi1.BitMapImageFile = img1;
            (DataContext).AddImage1.Execute(mi1);

            BitmapImage img2 = new BitmapImage(new Uri(imgPath2));
            MyImage mi2 = new MyImage();
            mi2.BitMapImageFile = img2;
            (DataContext).AddImage2.Execute(mi2);

            if (StaticSession.sm.PercentDifference < threshhold)
            {
                return true;
            }
            return false;
        }
    }
}

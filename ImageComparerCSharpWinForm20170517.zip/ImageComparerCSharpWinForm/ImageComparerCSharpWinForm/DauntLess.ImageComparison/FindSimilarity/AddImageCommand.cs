﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DauntLess.ImageComparison.FindSimilarity
{
    class AddImageCommand : CommandBase
    {
        private readonly ImageComparerViewModel _icwvm;
        private readonly int _imageNumber;
        public AddImageCommand(ImageComparerViewModel cvm, int imageNumber)
        {
            _icwvm = cvm;
            _imageNumber = imageNumber;
        }

        public override void Execute(object parameter)
        {
            _icwvm.AddAnImage((MyImage)parameter, _imageNumber);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace ImageComparerCSharpWinForm
{
    public class MyImage
    {
        public string FilePath { get; set; }
        public BitmapImage BitMapImageFile { get; set; }
        public Bitmap BitMapFile { get; set; }
    }
}

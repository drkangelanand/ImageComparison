﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageComparerCSharpWinForm
{
    public enum ImageRotation
    {
        None = 0, Rotate90, Rotate180, Rotate270
    }

    public class SimilarImage
    {
        public string SourceImage { get; set; }
        public string ComparedImage { get; set; }
        public ImageRotation ImgOrientation { get; set; }
        public double AverageDifference { get; set; }
        public double PercentDifference { get; set; }

        public void GetDifference(string sourceImage, string comparedImage,byte[,] sourceImageMatrix, byte[,] comparedImageMatrix)
        {
            this.SourceImage = sourceImage;
            this.ComparedImage = comparedImage;
            byte[,] differences = new byte[16, 16];
            byte[,] differences90 = new byte[16, 16];
            byte[,] differences180 = new byte[16, 16];
            byte[,] differences270 = new byte[16, 16];
            byte[,] firstGray = sourceImageMatrix;
            byte[,] secondGray = comparedImageMatrix;
            byte[,] secondGray270 = RotateMatrix(secondGray);
            byte[,] secondGray180 = RotateMatrix(secondGray270);
            byte[,] secondGray90 = RotateMatrix(secondGray180);
            double avg1 = 0, avg2 = 0, avg3 = 0, avg4 = 0;

            for (int y = 0; y < 16; y++)
            {
                for (int x = 0; x < 16; x++)
                {
                    differences[x, y] = (byte)Math.Abs(firstGray[x, y] - secondGray[x, y]);
                }
            }

            for (int y = 0; y < 16; y++)
            {
                for (int x = 0; x < 16; x++)
                {
                    differences90[x, y] = (byte)Math.Abs(firstGray[x, y] - secondGray90[x, y]);
                }
            }

            for (int y = 0; y < 16; y++)
            {
                for (int x = 0; x < 16; x++)
                {
                    differences180[x, y] = (byte)Math.Abs(firstGray[x, y] - secondGray180[x, y]);
                }
            }

            for (int y = 0; y < 16; y++)
            {
                for (int x = 0; x < 16; x++)
                {
                    differences270[x, y] = (byte)Math.Abs(firstGray[x, y] - secondGray270[x, y]);
                }
            }

            //List<string> dataArr = new List<string>();
            string data = string.Empty;

            for (int i = 0; i < 16; i++)
            {
                StringBuilder sb = new StringBuilder();
                for (int j = 0; j < 16; j++)
                {
                    avg1 += differences[j, i];
                    sb.Append(differences[j, i] + ", ");
                }
                //dataArr.Add(sb.ToString());
            }
            //dataArr.Add("Average : " + (avg1 / (16 * 16)));
            //avg1 = 0;

            //dataArr.Add("\r\n\r\n");

            for (int i = 0; i < 16; i++)
            {
                StringBuilder sb = new StringBuilder();
                for (int j = 0; j < 16; j++)
                {
                    avg2 += differences90[j, i];
                    sb.Append(differences90[j, i] + ", ");
                }
                //dataArr.Add(sb.ToString());
            }
            //dataArr.Add("Average : " + (avg2 / (16 * 16)));
            //avg2 = 0;

            //dataArr.Add("\r\n\r\n");

            for (int i = 0; i < 16; i++)
            {
                StringBuilder sb = new StringBuilder();
                for (int j = 0; j < 16; j++)
                {
                    avg3 += differences180[j, i];
                    sb.Append(differences180[j, i] + ", ");
                }
                //dataArr.Add(sb.ToString());
            }
            //dataArr.Add("Average : " + (avg3 / (16 * 16)));
            //avg3 = 0;

            //dataArr.Add("\r\n\r\n");

            for (int i = 0; i < 16; i++)
            {
                StringBuilder sb = new StringBuilder();
                for (int j = 0; j < 16; j++)
                {
                    avg4 += differences270[j, i];
                    sb.Append(differences270[j, i] + ", ");
                }
                //dataArr.Add(sb.ToString());
            }
            //dataArr.Add("Average Difference : " + (avg4 / (16 * 16)));
            //dataArr.Add("Average Percent Difference : " + (avg4 / (16 * 16)));
            //avg4 = 0;
            //File.WriteAllLines(@"D:\New folder (3)\imgDiff" + DateTime.Now.Ticks + ".txt", dataArr);
            double[] avgArr = { avg1, avg2, avg3, avg4 };
            double minAvg = avgArr.Min();
            if (avg1 == minAvg)
            {
                this.ImgOrientation = ImageRotation.None;
            }

            if (avg2 == minAvg)
            {
                this.ImgOrientation = ImageRotation.Rotate90;
            }

            if (avg3 == minAvg)
            {
                this.ImgOrientation = ImageRotation.Rotate180;
            }

            if (avg4 == minAvg)
            {
                this.ImgOrientation = ImageRotation.Rotate270;
            }

            this.AverageDifference = minAvg / 256;
            this.PercentDifference = (minAvg / 256) * 100 / 256;

            StaticSession.similarImagesList.Add(this);
            //else if()
        }

        static byte[,] RotateMatrix(byte[,] matrix)
        {
            byte[,] ret = new byte[16, 16];

            for (int i = 0; i < 16; ++i)
            {
                for (int j = 0; j < 16; ++j)
                {
                    ret[i, j] = matrix[16 - j - 1, i];
                }
            }

            return ret;
        }
    }
}
